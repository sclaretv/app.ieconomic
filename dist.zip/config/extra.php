<?php

	$config['currency_symbols'] = array(
		'Pesos' => '$',
        'Porcentaje' => '%',
        'Dólar' => 'US$',
	);

	define("CURRENCY_SYMBOLS", $config['currency_symbols']);
	
